/* =============================================
   api.js — Centralized fetch utility for CRM
   ============================================= */

// CRITICAL: Check if running from file system instead of server
if (window.location.protocol === 'file:') {
    alert('⚠️ ERROR: You opened the HTML file directly! \n\nPlease use http://localhost:5000 in your browser address bar.');
}

const API_BASE = '/api';

function getToken() {
    return localStorage.getItem('crm_token');
}

function authHeaders() {
    const token = getToken();
    return {
        'Content-Type': 'application/json',
        ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
    };
}

async function request(method, path, body) {
    const url = API_BASE + path;
    console.log(`[API] ${method} ${url}`, body || '');

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s timeout

    const opts = {
        method,
        headers: authHeaders(),
        signal: controller.signal
    };
    if (body !== undefined) opts.body = JSON.stringify(body);

    try {
        const res = await fetch(url, opts);
        clearTimeout(timeoutId);

        // Auto-logout on 401
        if (res.status === 401) {
            localStorage.removeItem('crm_token');
            localStorage.removeItem('crm_user');
            if (!window.location.pathname.includes('index'))
                window.location.href = '/index.html';
            throw new Error('Unauthorized');
        }

        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.message || `HTTP ${res.status}`);
        return data;
    } catch (err) {
        clearTimeout(timeoutId);
        if (err.name === 'AbortError') throw new Error('Request timed out (Server unresponsive)');
        throw err;
    }
}

const api = {
    get: (path) => request('GET', path),
    post: (path, body) => request('POST', path, body),
    put: (path, body) => request('PUT', path, body),
    patch: (path, body) => request('PATCH', path, body),
    delete: (path) => request('DELETE', path),
};
