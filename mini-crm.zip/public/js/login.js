/* =========================
   login.js — Login page logic
   ========================= */

// If already logged in, skip to dashboard
if (getToken()) window.location.href = '/dashboard.html';

const form = document.getElementById('loginForm');
const errorEl = document.getElementById('loginError');
const btnText = document.getElementById('btnText');
const btnSpinner = document.getElementById('btnSpinner');
const togglePw = document.getElementById('togglePw');
const pwInput = document.getElementById('password');

// Password visibility toggle
togglePw.addEventListener('click', () => {
    const isText = pwInput.type === 'text';
    pwInput.type = isText ? 'password' : 'text';
    togglePw.querySelector('svg').style.opacity = isText ? '1' : '0.5';
});

// Form submit
form.addEventListener('submit', async (e) => {
    e.preventDefault();
    errorEl.hidden = true;

    const username = form.username.value.trim();
    const password = form.password.value;

    if (!username || !password) {
        showError('Please enter username and password.');
        return;
    }

    setLoading(true);
    console.log('[Login] Attempting sign-in for:', username);

    try {
        const data = await api.post('/auth/login', { username, password });
        console.log('[Login] Success! Redirecting...');
        localStorage.setItem('crm_token', data.token);
        localStorage.setItem('crm_user', data.username);
        window.location.href = '/dashboard.html';
    } catch (err) {
        console.error('[Login] Error caught:', err);
        showError(`${err.message} (Is the server reachable?)`);
    } finally {
        console.log('[Login] Cleaning up loading state.');
        setLoading(false);
    }
});

function setLoading(loading) {
    form.querySelector('.btn-login').disabled = loading;
    btnText.hidden = loading;
    btnSpinner.hidden = !loading;
}

function showError(msg) {
    errorEl.textContent = msg;
    errorEl.hidden = false;
}
