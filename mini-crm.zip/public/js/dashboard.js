/* =======================================
   dashboard.js — Full CRM dashboard logic
   ======================================= */

// ---- Auth Guard ----
(function () {
    if (!getToken()) window.location.href = '/index.html';
    const user = localStorage.getItem('crm_user') || 'Admin';
    document.getElementById('adminName').textContent = user;
    document.getElementById('adminAvatar').textContent = user[0].toUpperCase();
})();

// ---- State ----
let allLeads = [];
let currentFilter = 'All';
let searchQuery = '';
let pendingDeleteId = null;
let pipelineChart = null;
let lastStats = null;

// ---- DOM refs ----
const leadsBody = document.getElementById('leadsBody');
const searchInput = document.getElementById('searchInput');
const filterTabs = document.querySelectorAll('.filter-tab');
const addLeadBtn = document.getElementById('addLeadBtn');
const leadModalOverlay = document.getElementById('leadModalOverlay');
const leadForm = document.getElementById('leadForm');
const modalTitle = document.getElementById('modalTitle');
const cancelLead = document.getElementById('cancelLead');
const modalClose = document.getElementById('modalClose');
const notesModalOverlay = document.getElementById('notesModalOverlay');
const notesModalClose = document.getElementById('notesModalClose');
const addNoteForm = document.getElementById('addNoteForm');
const notesList = document.getElementById('notesList');
const notesLeadName = document.getElementById('notesLeadName');
const notesLeadId = document.getElementById('notesLeadId');
const deleteModalOverlay = document.getElementById('deleteModalOverlay');
const deleteModalClose = document.getElementById('deleteModalClose');
const cancelDelete = document.getElementById('cancelDelete');
const confirmDelete = document.getElementById('confirmDelete');
const deleteLeadName = document.getElementById('deleteLeadName');
const logoutBtn = document.getElementById('logoutBtn');
const hamburger = document.getElementById('hamburger');
const sidebar = document.getElementById('sidebar');
const sidebarClose = document.getElementById('sidebarClose');
const sidebarOverlay = document.getElementById('sidebarOverlay');

// ---- Init ----
loadData();

async function loadData() {
    await Promise.all([loadLeads(), loadStats()]);
    updateChart();
}

// ---- Load & Render Leads ----
async function loadLeads() {
    try {
        const params = new URLSearchParams();
        if (searchQuery) params.set('search', searchQuery);
        if (currentFilter !== 'All') params.set('status', currentFilter);
        allLeads = await api.get('/leads?' + params.toString());
        renderTable(allLeads);
    } catch (err) {
        showToast('Failed to load leads: ' + err.message, 'error');
    }
}

function renderTable(leads) {
    if (!leads.length) {
        leadsBody.innerHTML = `
      <tr class="empty-row">
        <td colspan="7">
          <div class="empty-state">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/>
              <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>
            </svg>
            <p>No leads found. ${currentFilter !== 'All' || searchQuery ? 'Try adjusting your filters.' : 'Click <strong>Add Lead</strong> to get started.'}</p>
          </div>
        </td>
      </tr>`;
        return;
    }

    leadsBody.innerHTML = leads.map(lead => `
    <tr data-id="${lead._id}">
      <td>
        <div class="lead-name">${esc(lead.name)}</div>
        <div class="lead-email">${esc(lead.email)}</div>
      </td>
      <td>${esc(lead.email)}</td>
      <td class="hide-mobile">${esc(lead.company || '—')}</td>
      <td class="hide-mobile">${esc(lead.source)}</td>
      <td>
        <select class="status-select badge badge-${lead.status}" 
          data-id="${lead._id}" data-current="${lead.status}"
          aria-label="Status for ${esc(lead.name)}">
          <option value="New"       ${lead.status === 'New' ? 'selected' : ''}>🔵 New</option>
          <option value="Contacted" ${lead.status === 'Contacted' ? 'selected' : ''}>🟡 Contacted</option>
          <option value="Converted" ${lead.status === 'Converted' ? 'selected' : ''}>🟢 Converted</option>
        </select>
      </td>
      <td class="hide-mobile">
        ${lead.followUpDate ? `<span class="${followUpClass(lead.followUpDate)}">${formatDate(lead.followUpDate)}</span>` : '<span style="color:var(--text-muted)">—</span>'}
      </td>
      <td>
        <div class="action-btns">
          <button class="action-btn edit" data-id="${lead._id}" title="Edit lead">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
            </svg>
          </button>
          <button class="action-btn notes" data-id="${lead._id}" data-name="${esc(lead.name)}" title="Notes & follow-up">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
            </svg>
          </button>
          <button class="action-btn delete" data-id="${lead._id}" data-name="${esc(lead.name)}" title="Delete lead">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/>
              <path d="M10 11v6M14 11v6"/><path d="M9 6V4h6v2"/>
            </svg>
          </button>
        </div>
      </td>
    </tr>
  `).join('');

    // Attach row events
    leadsBody.querySelectorAll('.status-select').forEach(sel => {
        sel.addEventListener('change', handleStatusChange);
    });
    leadsBody.querySelectorAll('.action-btn.edit').forEach(btn => {
        btn.addEventListener('click', () => openEditModal(btn.dataset.id));
    });
    leadsBody.querySelectorAll('.action-btn.notes').forEach(btn => {
        btn.addEventListener('click', () => openNotesModal(btn.dataset.id, btn.dataset.name));
    });
    leadsBody.querySelectorAll('.action-btn.delete').forEach(btn => {
        btn.addEventListener('click', () => openDeleteModal(btn.dataset.id, btn.dataset.name));
    });
}

// ---- Stats ----
async function loadStats() {
    try {
        const s = await api.get('/leads/stats');
        document.getElementById('statTotal').textContent = s.total;
        document.getElementById('statNew').textContent = s.new;
        document.getElementById('statContacted').textContent = s.contacted;
        document.getElementById('statConverted').textContent = s.converted;
        lastStats = s;
        updateChart(s);
    } catch { /* silent */ }
}

// ---- Chart Logic ----
function updateChart(stats) {
    if (!stats) stats = lastStats;
    if (!stats) return;

    const canvas = document.getElementById('pipelineChart');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    if (pipelineChart) {
        pipelineChart.destroy();
    }

    pipelineChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['New', 'Contacted', 'Converted'],
            datasets: [{
                data: [stats.new, stats.contacted, stats.converted],
                backgroundColor: ['#64dca0', '#fbbf24', '#50b4f0'],
                borderColor: '#050505',
                borderWidth: 3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { color: '#a1a1aa', padding: 20, font: { family: 'Inter', size: 12 } }
                }
            },
            cutout: '70%'
        }
    });
}

// ---- Search & Filter ----
let searchTimer;
searchInput.addEventListener('input', () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => {
        searchQuery = searchInput.value.trim();
        loadLeads();
    }, 350);
});

filterTabs.forEach(tab => {
    tab.addEventListener('click', () => {
        setFilter(tab.dataset.status);
    });
});

function setFilter(status) {
    filterTabs.forEach(t => {
        t.classList.toggle('active', t.dataset.status === status);
    });
    currentFilter = status;
    loadLeads();
}

// Stats card clicks
document.getElementById('cardTotal').addEventListener('click', () => {
    switchSection('leads');
    setFilter('All');
});
document.getElementById('cardNew').addEventListener('click', () => {
    switchSection('leads');
    setFilter('New');
});
document.getElementById('cardContacted').addEventListener('click', () => {
    switchSection('leads');
    setFilter('Contacted');
});
document.getElementById('cardConverted').addEventListener('click', () => {
    switchSection('leads');
    setFilter('Converted');
});

// ---- Status Change ----
async function handleStatusChange(e) {
    const sel = e.target;
    const id = sel.dataset.id;
    const status = sel.value;
    try {
        await api.patch(`/leads/${id}/status`, { status });
        sel.className = `status-select badge badge-${status}`;
        sel.dataset.current = status;
        await loadStats();
        showToast(`Status updated to ${status}`, 'success');
    } catch (err) {
        sel.value = sel.dataset.current; // revert
        showToast('Failed to update status: ' + err.message, 'error');
    }
}

// ---- ADD / EDIT MODAL ----
function openAddModal() {
    leadForm.reset();
    document.getElementById('leadId').value = '';
    modalTitle.textContent = 'Add Lead';
    document.getElementById('saveLeadBtn').textContent = 'Add Lead';
    document.getElementById('leadFormError').hidden = true;
    leadModalOverlay.hidden = false;
    document.getElementById('leadName').focus();
}

async function openEditModal(id) {
    const lead = allLeads.find(l => l._id === id);
    if (!lead) return;
    leadForm.reset();
    document.getElementById('leadId').value = lead._id;
    document.getElementById('leadName').value = lead.name;
    document.getElementById('leadEmail').value = lead.email;
    document.getElementById('leadPhone').value = lead.phone || '';
    document.getElementById('leadCompany').value = lead.company || '';
    document.getElementById('leadSource').value = lead.source;
    document.getElementById('leadStatus').value = lead.status;
    document.getElementById('leadFollowUp').value = lead.followUpDate
        ? new Date(lead.followUpDate).toISOString().slice(0, 10) : '';
    modalTitle.textContent = 'Edit Lead';
    document.getElementById('saveLeadBtn').textContent = 'Save Changes';
    document.getElementById('leadFormError').hidden = true;
    leadModalOverlay.hidden = false;
    document.getElementById('leadName').focus();
}

function closeLeadModal() { leadModalOverlay.hidden = true; }

addLeadBtn.addEventListener('click', openAddModal);
cancelLead.addEventListener('click', closeLeadModal);
modalClose.addEventListener('click', closeLeadModal);
leadModalOverlay.addEventListener('click', e => { if (e.target === leadModalOverlay) closeLeadModal(); });

leadForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const errorEl = document.getElementById('leadFormError');
    errorEl.hidden = true;

    const id = document.getElementById('leadId').value;
    const payload = {
        name: document.getElementById('leadName').value.trim(),
        email: document.getElementById('leadEmail').value.trim(),
        phone: document.getElementById('leadPhone').value.trim(),
        company: document.getElementById('leadCompany').value.trim(),
        source: document.getElementById('leadSource').value,
        status: document.getElementById('leadStatus').value,
        followUpDate: document.getElementById('leadFollowUp').value || null,
    };

    if (!payload.name || !payload.email) {
        errorEl.textContent = 'Name and email are required.';
        errorEl.hidden = false;
        return;
    }

    const btn = document.getElementById('saveLeadBtn');
    btn.disabled = true;
    btn.textContent = 'Saving…';

    try {
        if (id) {
            await api.put(`/leads/${id}`, payload);
            showToast('Lead updated successfully!', 'success');
        } else {
            await api.post('/leads', payload);
            showToast('Lead added successfully!', 'success');
        }
        closeLeadModal();
        await loadData();
    } catch (err) {
        errorEl.textContent = err.message || 'Failed to save lead.';
        errorEl.hidden = false;
    } finally {
        btn.disabled = false;
        btn.textContent = id ? 'Save Changes' : 'Add Lead';
    }
});

// ---- NOTES MODAL ----
async function openNotesModal(id, name) {
    notesLeadId.value = id;
    notesLeadName.textContent = name;
    document.getElementById('noteText').value = '';
    notesModalOverlay.hidden = false;
    await renderNotes(id);
}

async function renderNotes(id) {
    try {
        const lead = await api.get(`/leads?search=${id}`).catch(() => null);
        const found = allLeads.find(l => l._id === id);
        const notes = found ? found.notes : [];
        if (!notes.length) {
            notesList.innerHTML = '<p class="notes-empty">No notes yet. Add one below.</p>';
            return;
        }
        notesList.innerHTML = notes.slice().reverse().map(n => `
      <div class="note-item">
        <p class="note-text">${esc(n.text)}</p>
        <p class="note-date">${new Date(n.createdAt).toLocaleString()}</p>
        <button class="note-delete" data-lead="${id}" data-note="${n._id}" title="Delete note">✕</button>
      </div>
    `).join('');
        notesList.querySelectorAll('.note-delete').forEach(btn => {
            btn.addEventListener('click', () => deleteNote(btn.dataset.lead, btn.dataset.note));
        });
    } catch { /* ok */ }
}

notesModalClose.addEventListener('click', () => { notesModalOverlay.hidden = true; });
notesModalOverlay.addEventListener('click', e => { if (e.target === notesModalOverlay) notesModalOverlay.hidden = true; });

addNoteForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const text = document.getElementById('noteText').value.trim();
    const id = notesLeadId.value;
    if (!text) return;
    try {
        const updated = await api.post(`/leads/${id}/notes`, { text });
        // Update local state
        const idx = allLeads.findIndex(l => l._id === id);
        if (idx > -1) allLeads[idx] = updated;
        document.getElementById('noteText').value = '';
        await renderNotes(id);
        showToast('Note added!', 'success');
    } catch (err) {
        showToast('Failed to add note: ' + err.message, 'error');
    }
});

async function deleteNote(leadId, noteId) {
    try {
        const updated = await api.delete(`/leads/${leadId}/notes/${noteId}`);
        const idx = allLeads.findIndex(l => l._id === leadId);
        if (idx > -1) allLeads[idx] = updated;
        await renderNotes(leadId);
        showToast('Note deleted', 'success');
    } catch (err) {
        showToast('Failed to delete note: ' + err.message, 'error');
    }
}

// ---- DELETE MODAL ----
function openDeleteModal(id, name) {
    pendingDeleteId = id;
    deleteLeadName.textContent = name;
    deleteModalOverlay.hidden = false;
}

function closeDeleteModal() {
    deleteModalOverlay.hidden = true;
    pendingDeleteId = null;
}

deleteModalClose.addEventListener('click', closeDeleteModal);
cancelDelete.addEventListener('click', closeDeleteModal);
deleteModalOverlay.addEventListener('click', e => { if (e.target === deleteModalOverlay) closeDeleteModal(); });

confirmDelete.addEventListener('click', async () => {
    if (!pendingDeleteId) return;
    confirmDelete.disabled = true;
    confirmDelete.textContent = 'Deleting…';
    try {
        await api.delete(`/leads/${pendingDeleteId}`);
        showToast('Lead deleted', 'success');
        closeDeleteModal();
        await loadData();
    } catch (err) {
        showToast('Delete failed: ' + err.message, 'error');
    } finally {
        confirmDelete.disabled = false;
        confirmDelete.textContent = 'Delete';
    }
});

// ---- Logout ----
logoutBtn.addEventListener('click', () => {
    localStorage.removeItem('crm_token');
    localStorage.removeItem('crm_user');
    window.location.href = '/index.html';
});

// ---- Mobile Sidebar ----
hamburger.addEventListener('click', () => {
    sidebar.classList.add('open');
    sidebarOverlay.classList.add('active');
});
sidebarClose.addEventListener('click', closeSidebar);
sidebarOverlay.addEventListener('click', closeSidebar);
function closeSidebar() {
    sidebar.classList.remove('open');
    sidebarOverlay.classList.remove('active');
}

// ---- Section Switching ----
function switchSection(id) {
    document.querySelectorAll('.dashboard-section').forEach(s => {
        s.hidden = true;
        s.classList.remove('fade-in');
    });

    const target = document.getElementById(`section-${id}`);
    target.hidden = false;
    setTimeout(() => target.classList.add('fade-in'), 10);

    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.toggle('active', item.dataset.section === id);
    });

    document.getElementById('pageTitle').textContent = id === 'overview' ? 'Dashboard' : 'Lead Management';
    if (id === 'overview') updateChart();
}

document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', (e) => {
        e.preventDefault();
        switchSection(item.dataset.section === 'dashboard' ? 'overview' : 'leads');
        closeSidebar();
    });
});

// ---- CSV Export ----
document.getElementById('exportCsvBtn').addEventListener('click', () => {
    if (!allLeads.length) return showToast('No leads to export', 'error');

    const headers = ['Name', 'Email', 'Phone', 'Company', 'Source', 'Status', 'Follow-up'];
    const rows = allLeads.map(l => [
        `"${l.name}"`,
        `"${l.email}"`,
        `"${l.phone || ''}"`,
        `"${l.company || ''}"`,
        `"${l.source}"`,
        `"${l.status}"`,
        `"${l.followUpDate ? new Date(l.followUpDate).toLocaleDateString() : ''}"`
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `leads_export_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Leads exported to CSV', 'success');
});

// Close modals on Escape
document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
        closeLeadModal();
        notesModalOverlay.hidden = true;
        closeDeleteModal();
        closeSidebar();
    }
});

// ---- Helpers ----
function esc(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;')
        .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function formatDate(iso) {
    if (!iso) return '';
    return new Date(iso).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
}

function followUpClass(iso) {
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const d = new Date(iso); d.setHours(0, 0, 0, 0);
    if (d < today) return 'followup-date overdue';
    if (d.getTime() === today.getTime()) return 'followup-date today';
    return 'followup-date';
}

// ---- Toast ----
let toastTimer;
function showToast(msg, type = '') {
    const toast = document.getElementById('toast');
    toast.textContent = msg;
    toast.className = 'toast' + (type ? ' ' + type : '');
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 3000);
}
