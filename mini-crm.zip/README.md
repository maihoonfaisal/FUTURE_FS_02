# 🚀 MiniCRM — Full Stack CRM

A professional, responsive, and secure Customer Relationship Management application built with Node.js, Express, and MongoDB. Perfect for small businesses to track leads and sales pipelines.

![Dashboard Preview](public/dashboard.html) <!-- Placeholder for when user adds screenshot -->

## ✨ Features
- **Lead Management**: Full CRUD operations for sales leads.
- **Status Tracking**: Color-coded badges for New, Contacted, and Converted leads.
- **Notes & Follow-ups**: Add time-stamped notes and track follow-up dates (overdue dates show in red).
- **Dashboard Stats**: Real-time counters for your sales pipeline.
- **Secure Access**: JWT-based authentication for admin only.
- **Premium UI**: Modern dark theme with glassmorphism and smooth animations.
- **Cloud Ready**: Configured for MongoDB Atlas with built-in DNS SRV fixes.

## 🛠️ Tech Stack
- **Frontend**: HTML5, Vanilla CSS3 (Custom Design System), JavaScript (ES6+)
- **Backend**: Node.js, Express.js
- **Database**: MongoDB (Mongoose ODM)
- **Auth**: JSON Web Tokens (JWT) & BcryptJS

## 🚀 Getting Started

### 1. Database Setup
Ensure you have a MongoDB Atlas connection string and your IP is whitelisted.
- Create a `.env` file in the root (see `.env.example` for details).
- Add your `MONGO_URI` and a secure `JWT_SECRET`.

### 2. Installation
```bash
npm install
```

### 3. Initialize Admin
Run the seed script once to create the default admin account:
```bash
node seed.js
```
*Default Credentials: `admin` / `admin123`*

### 4. Start Server
```bash
npm start
```
Visit `http://localhost:5000` to access the CRM.

## 📱 Responsiveness
The CRM is fully responsive and optimized for Desktop, Tablet, and Mobile devices with a collapsible sidebar and mobile-friendly table layouts.

## 📄 License
ISC License — Feel free to use this as a base for your own projects!

## 🔧 Troubleshooting

### "Failed to Fetch" or Connection Errors
If you see error messages about connecting to the API:
1. **Check the Server**: Ensure you ran `npm start` and the console says `🚀 Server running`.
2. **Port Mismatch**: If you are using VS Code "Live Server" (usually port 5500), the app is designed to automatically find the backend on port 5000. Ensure no other service is blocking port 5000.
3. **CORS**: The server includes CORS support, but ensure your browser isn't blocking local requests.
