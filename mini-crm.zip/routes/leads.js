const express = require('express');
const Lead = require('../models/Lead');
const auth = require('../middleware/auth');

const router = express.Router();

// All routes protected
router.use(auth);

// GET /api/leads — list all, with optional search & status filter
router.get('/', async (req, res) => {
    try {
        const { search = '', status } = req.query;
        const query = {};
        if (status && status !== 'All') query.status = status;
        if (search) {
            query.$or = [
                { name: { $regex: search, $options: 'i' } },
                { email: { $regex: search, $options: 'i' } },
                { company: { $regex: search, $options: 'i' } },
            ];
        }
        const leads = await Lead.find(query).sort({ createdAt: -1 });
        res.json(leads);
    } catch (err) {
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});

// GET /api/leads/stats — dashboard stats
router.get('/stats', async (req, res) => {
    try {
        const total = await Lead.countDocuments();
        const newLeads = await Lead.countDocuments({ status: 'New' });
        const contacted = await Lead.countDocuments({ status: 'Contacted' });
        const converted = await Lead.countDocuments({ status: 'Converted' });
        res.json({ total, new: newLeads, contacted, converted });
    } catch (err) {
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});

// POST /api/leads — create a new lead
router.post('/', async (req, res) => {
    try {
        const lead = await Lead.create(req.body);
        res.status(201).json(lead);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// PUT /api/leads/:id — full update
router.put('/:id', async (req, res) => {
    try {
        const lead = await Lead.findByIdAndUpdate(req.params.id, req.body, {
            new: true, runValidators: true,
        });
        if (!lead) return res.status(404).json({ message: 'Lead not found' });
        res.json(lead);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// PATCH /api/leads/:id/status — quick status change
router.patch('/:id/status', async (req, res) => {
    try {
        const { status } = req.body;
        const lead = await Lead.findByIdAndUpdate(
            req.params.id,
            { status },
            { new: true, runValidators: true }
        );
        if (!lead) return res.status(404).json({ message: 'Lead not found' });
        res.json(lead);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// POST /api/leads/:id/notes — add a note
router.post('/:id/notes', async (req, res) => {
    try {
        const lead = await Lead.findById(req.params.id);
        if (!lead) return res.status(404).json({ message: 'Lead not found' });
        lead.notes.push({ text: req.body.text });
        await lead.save();
        res.json(lead);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// DELETE /api/leads/:id/notes/:noteId — delete a specific note
router.delete('/:id/notes/:noteId', async (req, res) => {
    try {
        const lead = await Lead.findById(req.params.id);
        if (!lead) return res.status(404).json({ message: 'Lead not found' });
        lead.notes = lead.notes.filter(n => n._id.toString() !== req.params.noteId);
        await lead.save();
        res.json(lead);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// PATCH /api/leads/:id/followup — set follow-up date
router.patch('/:id/followup', async (req, res) => {
    try {
        const lead = await Lead.findByIdAndUpdate(
            req.params.id,
            { followUpDate: req.body.followUpDate },
            { new: true }
        );
        if (!lead) return res.status(404).json({ message: 'Lead not found' });
        res.json(lead);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// DELETE /api/leads/:id — delete a lead
router.delete('/:id', async (req, res) => {
    try {
        const lead = await Lead.findByIdAndDelete(req.params.id);
        if (!lead) return res.status(404).json({ message: 'Lead not found' });
        res.json({ message: 'Lead deleted' });
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

module.exports = router;
