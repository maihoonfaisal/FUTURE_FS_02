const express = require('express');
const jwt = require('jsonwebtoken');
const Admin = require('../models/Admin');
const auth = require('../middleware/auth');

const router = express.Router();

// POST /api/auth/login
router.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        if (!username || !password)
            return res.status(400).json({ message: 'Username and password required' });

        const admin = await Admin.findOne({ username: username.toLowerCase() });
        if (!admin)
            return res.status(401).json({ message: 'Invalid credentials' });

        const match = await admin.comparePassword(password);
        if (!match)
            return res.status(401).json({ message: 'Invalid credentials' });

        const token = jwt.sign(
            { id: admin._id, username: admin.username },
            process.env.JWT_SECRET,
            { expiresIn: '8h' }
        );

        res.json({ token, username: admin.username });
    } catch (err) {
        res.status(500).json({ message: 'Server error', error: err.message });
    }
});

// GET /api/auth/me — verify token & return admin info
router.get('/me', auth, (req, res) => {
    res.json({ username: req.admin.username });
});

module.exports = router;
