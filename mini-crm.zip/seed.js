require('dns').setServers(['8.8.8.8', '1.1.1.1']);
require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const Admin = require('./models/Admin');

async function seed() {
    await mongoose.connect(process.env.MONGO_URI);
    const exists = await Admin.findOne({ username: 'admin' });
    if (exists) {
        console.log('ℹ️  Admin already exists. No changes made.');
    } else {
        // Pre-hash to avoid double-hashing with the pre-save hook
        const hashed = await bcrypt.hash('admin123', 12);
        // Use new + save so the pre-save hook is skipped (password already hashed)
        const admin = new Admin({ username: 'admin', password: hashed });
        admin.$set('password', hashed); // mark unmodified so hook skips rehash
        await Admin.collection.insertOne({ username: 'admin', password: hashed });
        console.log('✅ Admin created → username: admin  password: admin123');
    }
    await mongoose.disconnect();
}

seed().catch(err => { console.error(err.message); process.exit(1); });
